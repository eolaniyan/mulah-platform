# SubSync v2 Web MVP
Upgrades:
* Fee preview modal
* Free-run counter (2 free runs)
* €3.99 flat fee for free users after limit
* Premium hybrid fee engine
* Auto-run toggle
* Tailwind UI refresh
Run:
```bash
npm install
npm start
```