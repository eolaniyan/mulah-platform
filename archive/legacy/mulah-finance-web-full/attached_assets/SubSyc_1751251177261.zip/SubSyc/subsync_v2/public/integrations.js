
/* ------------- Service Integrations JavaScript ------------- */

// Mock service configurations (in production, these would be real OAuth endpoints)
const serviceConfigs = {
  netflix: {
    name: 'Netflix',
    authUrl: 'https://api.netflix.com/oauth/authorize', // Mock URL
    scopes: ['billing:read', 'subscription:read']
  },
  spotify: {
    name: 'Spotify',
    authUrl: 'https://accounts.spotify.com/authorize',
    scopes: ['user-read-subscription-details']
  },
  disney: {
    name: 'Disney+',
    authUrl: 'https://api.disneyplus.com/oauth/authorize', // Mock URL
    scopes: ['subscription:read']
  },
  adobe: {
    name: 'Adobe Creative Cloud',
    authUrl: 'https://ims-na1.adobelogin.com/ims/authorize/v1', // Real Adobe OAuth
    scopes: ['openid', 'creative_sdk']
  },
  notion: {
    name: 'Notion',
    authUrl: 'https://api.notion.com/v1/oauth/authorize',
    scopes: ['read']
  },
  github: {
    name: 'GitHub',
    authUrl: 'https://github.com/login/oauth/authorize',
    scopes: ['user:email', 'read:org']
  }
};

// Demo subscription data that would be fetched from APIs
const mockApiData = {
  netflix: {
    cost: 15.49,
    plan: 'Premium',
    nextBilling: '2025-02-15',
    cycle: 'monthly'
  },
  spotify: {
    cost: 9.99,
    plan: 'Premium Individual',
    nextBilling: '2025-02-10',
    cycle: 'monthly'
  },
  disney: {
    cost: 7.99,
    plan: 'Disney+ Premium',
    nextBilling: '2025-02-20',
    cycle: 'monthly'
  }
};

// Handle service connection
document.addEventListener('click', (e) => {
  if (e.target.classList.contains('connect-btn')) {
    const serviceItem = e.target.closest('.integration-item');
    const serviceName = serviceItem.dataset.service;
    
    connectService(serviceName, e.target);
  }
});

function connectService(serviceName, button) {
  const originalText = button.textContent;
  button.textContent = 'Connecting...';
  button.disabled = true;

  // In a real implementation, this would redirect to OAuth flow
  // For demo purposes, we'll simulate the connection
  setTimeout(() => {
    if (mockApiData[serviceName]) {
      // Simulate successful connection and data retrieval
      showConnectionSuccess(serviceName, mockApiData[serviceName]);
      button.textContent = 'Connected ✓';
      button.classList.remove('bg-indigo-600', 'hover:bg-indigo-700');
      button.classList.add('bg-green-600', 'hover:bg-green-700');
      
      // Auto-add subscription to dashboard
      addSubscriptionFromIntegration(serviceName, mockApiData[serviceName]);
    } else {
      // Show OAuth modal for services without mock data
      showOAuthModal(serviceName);
      button.textContent = originalText;
      button.disabled = false;
    }
  }, 1500);
}

function showConnectionSuccess(serviceName, data) {
  const modal = document.createElement('div');
  modal.className = 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50';
  modal.innerHTML = `
    <div class="bg-white rounded-lg shadow-xl max-w-md w-full mx-4 p-6">
      <div class="text-center">
        <div class="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-green-100 mb-4">
          <span class="text-green-600 text-xl">✓</span>
        </div>
        <h3 class="text-lg font-medium text-gray-900 mb-2">Connected Successfully!</h3>
        <p class="text-gray-600 mb-4">Retrieved ${serviceConfigs[serviceName].name} subscription details:</p>
        
        <div class="bg-gray-50 rounded p-4 text-left mb-4">
          <div class="text-sm space-y-1">
            <div><strong>Plan:</strong> ${data.plan}</div>
            <div><strong>Cost:</strong> €${data.cost}/month</div>
            <div><strong>Next Billing:</strong> ${data.nextBilling}</div>
          </div>
        </div>
        
        <div class="flex space-x-3">
          <button id="addToDashboard" class="flex-1 bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700">
            Add to Dashboard
          </button>
          <button id="closeModal" class="flex-1 bg-gray-300 text-gray-700 px-4 py-2 rounded hover:bg-gray-400">
            Close
          </button>
        </div>
      </div>
    </div>
  `;

  document.body.appendChild(modal);

  document.getElementById('addToDashboard').addEventListener('click', () => {
    modal.remove();
    window.location.href = 'dashboard.html';
  });

  document.getElementById('closeModal').addEventListener('click', () => {
    modal.remove();
  });
}

function showOAuthModal(serviceName) {
  const config = serviceConfigs[serviceName];
  const modal = document.createElement('div');
  modal.className = 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50';
  modal.innerHTML = `
    <div class="bg-white rounded-lg shadow-xl max-w-md w-full mx-4 p-6">
      <h3 class="text-lg font-medium text-gray-900 mb-4">Connect ${config.name}</h3>
      <p class="text-gray-600 mb-4">This integration requires OAuth authentication. In a production app, you would be redirected to ${config.name}'s login page.</p>
      
      <div class="bg-blue-50 rounded p-4 mb-4">
        <p class="text-sm text-blue-800">
          <strong>Required permissions:</strong><br>
          ${config.scopes.join(', ')}
        </p>
      </div>
      
      <div class="bg-yellow-50 rounded p-4 mb-4">
        <p class="text-sm text-yellow-800">
          <strong>Demo Mode:</strong> This is a prototype. Real OAuth integration would be implemented in production.
        </p>
      </div>
      
      <div class="flex space-x-3">
        <button id="mockConnect" class="flex-1 bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700">
          Simulate Connection
        </button>
        <button id="closeModal" class="flex-1 bg-gray-300 text-gray-700 px-4 py-2 rounded hover:bg-gray-400">
          Cancel
        </button>
      </div>
    </div>
  `;

  document.body.appendChild(modal);

  document.getElementById('mockConnect').addEventListener('click', () => {
    modal.remove();
    // Simulate successful connection without real data
    showSuccessMessage(`${config.name} connected successfully! (Demo mode)`);
  });

  document.getElementById('closeModal').addEventListener('click', () => {
    modal.remove();
  });
}

async function addSubscriptionFromIntegration(serviceName, data) {
  const subscriptionData = {
    name: serviceConfigs[serviceName].name,
    cost: data.cost,
    cycle: data.cycle,
    nextDate: data.nextBilling
  };

  try {
    const token = localStorage.getItem('authToken');
    await fetch('/api/subscriptions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify(subscriptionData)
    });
  } catch (error) {
    console.error('Failed to add subscription:', error);
  }
}

function showSuccessMessage(message) {
  const notification = document.createElement("div");
  notification.className = "fixed top-4 right-4 bg-green-500 text-white px-4 py-3 rounded-lg shadow-lg z-50";
  notification.textContent = message;
  document.body.appendChild(notification);

  setTimeout(() => {
    notification.remove();
  }, 3000);
}

// Logout functionality
document.getElementById('logoutBtn')?.addEventListener('click', () => {
  localStorage.removeItem('authToken');
  localStorage.removeItem('userName');
  localStorage.removeItem('userEmail');
  localStorage.removeItem('userPlan');
  window.location.href = 'index.html';
});

// Check authentication
const authToken = localStorage.getItem('authToken');
if (!authToken) {
  window.location.href = 'login.html';
}
