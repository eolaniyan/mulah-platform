
// Modal functionality
function showErrorModal(message) {
  document.getElementById('errorMessage').textContent = message;
  document.getElementById('errorModal').classList.remove('hidden');
}

function showSuccessModal(message, redirectUrl = null) {
  document.getElementById('successMessage').textContent = message;
  document.getElementById('successModal').classList.remove('hidden');
  
  if (redirectUrl) {
    setTimeout(() => {
      window.location.href = redirectUrl;
    }, 1500);
  }
}

function hideModals() {
  document.getElementById('errorModal').classList.add('hidden');
  document.getElementById('successModal').classList.add('hidden');
}

// Close modal event listeners
document.getElementById('closeErrorModal').addEventListener('click', hideModals);
document.getElementById('errorModal').addEventListener('click', (e) => {
  if (e.target.id === 'errorModal') hideModals();
});

// Tab switching functionality
const loginTab = document.getElementById('loginTab');
const registerTab = document.getElementById('registerTab');
const loginForm = document.getElementById('loginForm');
const registerForm = document.getElementById('registerForm');

loginTab.addEventListener('click', () => {
  loginTab.className = 'px-6 py-2 rounded-md text-sm font-medium bg-white text-indigo-600 shadow';
  registerTab.className = 'px-6 py-2 rounded-md text-sm font-medium text-gray-500 hover:text-gray-700';
  loginForm.classList.remove('hidden');
  registerForm.classList.add('hidden');
});

registerTab.addEventListener('click', () => {
  registerTab.className = 'px-6 py-2 rounded-md text-sm font-medium bg-white text-indigo-600 shadow';
  loginTab.className = 'px-6 py-2 rounded-md text-sm font-medium text-gray-500 hover:text-gray-700';
  registerForm.classList.remove('hidden');
  loginForm.classList.add('hidden');
});

// Login form submission
document.getElementById('loginFormSubmit').addEventListener('submit', async (e) => {
  e.preventDefault();
  
  const email = document.getElementById('loginEmail').value;
  const password = document.getElementById('loginPassword').value;
  
  try {
    const response = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password })
    });
    
    const data = await response.json();
    
    if (response.ok) {
      // Store auth token/user info
      localStorage.setItem('authToken', data.token);
      localStorage.setItem('userName', data.user.name);
      localStorage.setItem('userEmail', data.user.email);
      localStorage.setItem('userPlan', data.user.plan);
      
      // Show success message and redirect
      showSuccessModal('Login successful! Redirecting to dashboard...', 'dashboard.html');
    } else {
      showErrorModal(data.error || 'Login failed. Please check your credentials and try again.');
    }
  } catch (error) {
    showErrorModal('Network error. Please check your connection and try again.');
  }
});

// Register form submission
document.getElementById('registerFormSubmit').addEventListener('submit', async (e) => {
  e.preventDefault();
  
  const name = document.getElementById('registerName').value;
  const email = document.getElementById('registerEmail').value;
  const password = document.getElementById('registerPassword').value;
  const confirmPassword = document.getElementById('confirmPassword').value;
  
  // Validate password match
  if (password !== confirmPassword) {
    showErrorModal('Passwords do not match. Please ensure both password fields are identical.');
    return;
  }
  
  // Basic password validation
  if (password.length < 6) {
    showErrorModal('Password must be at least 6 characters long for security.');
    return;
  }
  
  try {
    const response = await fetch('/api/auth/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, email, password })
    });
    
    const data = await response.json();
    
    if (response.ok) {
      // Auto-login after successful registration
      localStorage.setItem('authToken', data.token);
      localStorage.setItem('userName', data.user.name);
      localStorage.setItem('userEmail', data.user.email);
      localStorage.setItem('userPlan', data.user.plan);
      
      showSuccessModal('Account created successfully! Welcome to SubSync!', 'dashboard.html');
    } else {
      showErrorModal(data.error || 'Registration failed. Please try again.');
    }
  } catch (error) {
    showErrorModal('Network error. Please check your connection and try again.');
  }
});
