
// Auth handling
const authToken = localStorage.getItem('authToken');
const userName = localStorage.getItem('userName');
const userEmail = localStorage.getItem('userEmail');
const userPlan = localStorage.getItem('userPlan');
const isAuthenticated = !!authToken;

// Redirect to login if not authenticated
if (!isAuthenticated) {
  window.location.href = 'login.html';
}

// Populate user information
function populateUserInfo() {
  const userNameInput = document.getElementById('userName');
  const userEmailInput = document.getElementById('userEmail');
  const userPlanDisplay = document.getElementById('userPlanDisplay');
  const upgradePlan = document.getElementById('upgradePlan');
  
  if (userName) userNameInput.value = userName;
  if (userEmail) userEmailInput.value = userEmail;
  
  if (userPlan === 'premium') {
    userPlanDisplay.textContent = 'Premium';
    userPlanDisplay.className = 'px-3 py-1 rounded text-sm bg-yellow-500 text-white';
    upgradePlan.classList.add('hidden');
  } else {
    userPlanDisplay.textContent = 'Free';
    userPlanDisplay.className = 'px-3 py-1 rounded text-sm bg-gray-500 text-white';
    upgradePlan.classList.remove('hidden');
  }
}

// Update user info in header
function updateUserUI() {
  const userInfo = document.getElementById('userInfo');
  const isPremium = userPlan === 'premium';
  
  if (isAuthenticated && userName) {
    const planBadge = isPremium ? 
      '<span class="ml-2 px-2 py-1 text-xs bg-yellow-500 text-white rounded">Premium</span>' : 
      '<span class="ml-2 px-2 py-1 text-xs bg-gray-500 text-white rounded">Free</span>';
    userInfo.innerHTML = `${userName}${planBadge}`;
  }
}

// Logout functionality
document.getElementById('logoutBtn')?.addEventListener('click', () => {
  localStorage.removeItem('authToken');
  localStorage.removeItem('userName');
  localStorage.removeItem('userEmail');
  localStorage.removeItem('userPlan');
  window.location.href = 'index.html';
});

// TrueLayer integration (placeholder)
document.querySelector('.bg-blue-500.hover\\:bg-blue-600').addEventListener('click', () => {
  alert('TrueLayer integration would open here in a real implementation. This would allow automatic transaction categorization and subscription detection.');
});

// Plan upgrade (placeholder)
document.getElementById('upgradePlan')?.addEventListener('click', () => {
  alert('Premium upgrade flow would open here. Premium users get unlimited runs with lower fees.');
});

// Edit account functionality
let isEditing = false;
document.getElementById('editAccountBtn')?.addEventListener('click', () => {
  if (!isEditing) {
    enableEditing();
  }
});

document.getElementById('saveAccount')?.addEventListener('click', () => {
  saveAccountChanges();
});

document.getElementById('cancelEdit')?.addEventListener('click', () => {
  cancelEditing();
});

// Cancel subscription
document.getElementById('cancelSubscription')?.addEventListener('click', () => {
  if (confirm('Are you sure you want to cancel auto-renewal? Your premium features will remain active until the end of your current billing period.')) {
    alert('Auto-renewal cancelled. You will receive a confirmation email shortly.');
  }
});

function enableEditing() {
  isEditing = true;
  const nameInput = document.getElementById('userName');
  const emailInput = document.getElementById('userEmail');
  const editBtn = document.getElementById('editAccountBtn');
  const editActions = document.getElementById('editActions');
  
  nameInput.readOnly = false;
  emailInput.readOnly = false;
  nameInput.classList.remove('bg-gray-50');
  emailInput.classList.remove('bg-gray-50');
  nameInput.classList.add('bg-white');
  emailInput.classList.add('bg-white');
  
  editBtn.textContent = 'Editing...';
  editBtn.disabled = true;
  editActions.classList.remove('hidden');
}

function saveAccountChanges() {
  // In a real app, this would make an API call
  const newName = document.getElementById('userName').value;
  const newEmail = document.getElementById('userEmail').value;
  
  localStorage.setItem('userName', newName);
  localStorage.setItem('userEmail', newEmail);
  
  alert('Account information updated successfully!');
  cancelEditing();
  updateUserUI();
}

function cancelEditing() {
  isEditing = false;
  const nameInput = document.getElementById('userName');
  const emailInput = document.getElementById('userEmail');
  const editBtn = document.getElementById('editAccountBtn');
  const editActions = document.getElementById('editActions');
  
  // Restore original values
  nameInput.value = userName;
  emailInput.value = userEmail;
  
  nameInput.readOnly = true;
  emailInput.readOnly = true;
  nameInput.classList.add('bg-gray-50');
  emailInput.classList.add('bg-gray-50');
  nameInput.classList.remove('bg-white');
  emailInput.classList.remove('bg-white');
  
  editBtn.textContent = 'Edit';
  editBtn.disabled = false;
  editActions.classList.add('hidden');
}

// Show cancel subscription button for premium users
function updateCancelButton() {
  const cancelBtn = document.getElementById('cancelSubscription');
  if (userPlan === 'premium') {
    cancelBtn.classList.remove('hidden');
  }
}

// Initialize page
populateUserInfo();
updateUserUI();
updateCancelButton();
