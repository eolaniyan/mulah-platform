/* ------------- SubSync v2 – script.js (patched) ------------- */
const FREE_RUN_LIMIT = 2;
const ONE_OFF_FEE = 3.99;

/* Auth handling */
const authToken = localStorage.getItem('authToken');
const userName = localStorage.getItem('userName');
const isAuthenticated = !!authToken;

// Redirect to login if not authenticated
if (!isAuthenticated) {
  window.location.href = 'login.html';
}

/* Set user plan and premium status */
const userPlan = localStorage.getItem('userPlan') || 'free';
let isPremium = userPlan === 'premium';

function getAuthHeaders() {
  return authToken ? { 'Authorization': `Bearer ${authToken}` } : {};
}

/* Local-storage keys */
const RUN_KEY = "uswRuns";
const AUTO_KEY = "autoRun";

/* Undo delete functionality */
let deletedQueue = [];
let undoTimer = null;
const UNDO_TIMEOUT = 5000; // 5 seconds

/* ---------------- Utility ---------------- */
const getRuns = () => Number(localStorage.getItem(RUN_KEY) || "0");
const incRuns = () => localStorage.setItem(RUN_KEY, getRuns() + 1);

/* ---------------- UI helpers ---------------- */
function updateRunInfo() {
  const info = document.getElementById("runInfo");
  if (isPremium) {
    info.textContent = "Premium active (3 subs or €60 included).";
  } else {
    const remain = Math.max(0, FREE_RUN_LIMIT - getRuns());
    info.textContent = `Free runs left: ${remain}. Afterwards €${ONE_OFF_FEE} per run.`;
  }
}

function showUndoNotification() {
  // Remove existing notification if any
  const existing = document.getElementById("undoNotification");
  if (existing) existing.remove();

  if (deletedQueue.length === 0) return;

  const lastDeleted = deletedQueue[deletedQueue.length - 1];
  const queueCount = deletedQueue.length;

  // Create undo notification
  const notification = document.createElement("div");
  notification.id = "undoNotification";
  notification.className = "fixed top-4 right-4 bg-red-500 text-white px-4 py-3 rounded-lg shadow-lg flex items-center space-x-3 z-50";
  notification.innerHTML = `
    <div class="flex flex-col">
      <div class="flex items-center space-x-3">
        <span>Deleted "${lastDeleted.name}"${queueCount > 1 ? ` (+${queueCount - 1} more)` : ''}</span>
        <button id="undoBtn" class="bg-white text-red-500 px-3 py-1 rounded text-sm font-medium hover:bg-gray-100">
          ↶ Undo${queueCount > 1 ? ` (${queueCount})` : ''}
        </button>
      </div>
      <div class="mt-2 w-full bg-red-700 rounded-full h-1">
        <div id="undoProgress" class="bg-white h-1 rounded-full transition-all duration-100" style="width: 100%"></div>
      </div>
    </div>
  `;

  document.body.appendChild(notification);

  // Start countdown animation
  let timeLeft = UNDO_TIMEOUT;
  const progressBar = document.getElementById("undoProgress");
  const progressInterval = setInterval(() => {
    timeLeft -= 100;
    const percentage = Math.max(0, (timeLeft / UNDO_TIMEOUT) * 100);
    progressBar.style.width = `${percentage}%`;

    if (timeLeft <= 0) {
      clearInterval(progressInterval);
    }
  }, 100);

  // Reset timer - always give 5 seconds from the last delete
  if (undoTimer) clearTimeout(undoTimer);
  undoTimer = setTimeout(() => {
    clearInterval(progressInterval);
    // Keep only the most recent deletion after timeout
    if (deletedQueue.length > 1) {
      deletedQueue = [deletedQueue[deletedQueue.length - 1]];
      showUndoNotification(); // Update notification to show only 1 item
    } else {
      notification.remove();
      deletedQueue = [];
    }
  }, UNDO_TIMEOUT);
}

/* ---------------- Fetch & render subs ---------------- */
async function fetchSubs() {
  const res = await fetch("/api/subscriptions", {
    headers: getAuthHeaders()
  });
  const subs = await res.json();

  /* Build table */
  const tbody = document.getElementById("subsBody");
  tbody.innerHTML = "";
  subs.forEach((s, idx) => {
    tbody.insertAdjacentHTML(
      "beforeend",
      `<tr>
         <td class="px-4 py-2">${s.name}</td>
         <td class="px-4 py-2">€${s.cost.toFixed(2)}</td>
         <td class="px-4 py-2">${s.cycle}</td>
         <td class="px-4 py-2">${s.nextDate}</td>
         <td class="px-4 py-2">
           <button class="delete-btn text-red-600" data-id="${s.id}">❌</button>
         </td>
       </tr>`,
    );
  });

  /* Update total */
  const total = subs.reduce((sum, s) => sum + s.cost, 0);
  document.getElementById("total").textContent = `€${total.toFixed(2)}`;

  return { subs, total };
}

/* ---------------- Hybrid fee (bug-fixed) ---------------- */
function premiumFee(subs, total) {
  /* €1 per extra sub over three */
  const subFee = Math.max(0, subs.length - 3) * 1;
  /* Tiered % of amount over €60 */
  const overAmount = Math.max(0, total - 60);
  const tierPct =
    overAmount <= 0
      ? 0
      : overAmount <= 20
        ? 0.03
        : overAmount <= 40
          ? 0.04
          : 0.05;
  const amtFee = overAmount * tierPct;

  /* ---------- BUG FIX ---------- 
     floor €1 *only* when a fee is actually due */
  const raw = Math.max(subFee, amtFee);
  const fee = raw === 0 ? 0 : Math.max(1, raw);
  return fee.toFixed(2);
}

/* ---------------- Handle Pay (USW) ---------------- */
async function handlePay() {
  const { subs, total } = await fetchSubs();

  let fee = 0;
  let msg = "";

  if (isPremium) {
    fee = premiumFee(subs, total);
    msg =
      fee === "0.00"
        ? "No fee this month – all within Premium allowance. Proceed?"
        : `Premium fee €${fee}. Proceed?`;
  } else {
    if (getRuns() < FREE_RUN_LIMIT) {
      msg = "This run is free. Proceed?";
    } else {
      fee = ONE_OFF_FEE;
      msg = `This run costs €${fee}. Upgrade to Premium for unlimited low-fee runs. Proceed?`;
    }
  }

  showModal(msg, () => {
    if (!isPremium && getRuns() >= FREE_RUN_LIMIT) {
      alert(`Charged €${fee} (simulated).`);
    }
    incRuns();
    updateRunInfo();
    alert("USW run scheduled (simulated).");
  });
}

/* ---------------- Modal helper ---------------- */
function showModal(text, onConfirm) {
  const modal = document.getElementById("modal");
  document.getElementById("modalText").textContent = text;
  modal.classList.remove("hidden");

  const confirm = () => {
    onConfirm();
    cleanup();
  };
  const cleanup = () => {
    modal.classList.add("hidden");
    ok.removeEventListener("click", confirm);
  };

  const ok = document.getElementById("confirmModal");
  ok.addEventListener("click", confirm);
  document.getElementById("cancelModal").onclick = cleanup;
}

/* ---------------- Subscription suggestions ---------------- */
const popularSubscriptions = [
  { name: "Netflix", cost: 12.99 },
  { name: "Spotify", cost: 9.99 },
  { name: "Disney+", cost: 7.99 },
  { name: "YouTube Premium", cost: 11.99 },
  { name: "Amazon Prime", cost: 8.99 },
  { name: "Apple Music", cost: 9.99 },
  { name: "Adobe Creative Suite", cost: 52.99 },
  { name: "Microsoft 365", cost: 6.99 },
  { name: "iCloud+", cost: 2.99 },
  { name: "Dropbox", cost: 9.99 },
  { name: "GitHub Pro", cost: 4.00 },
  { name: "Figma Pro", cost: 12.00 },
  { name: "Notion Pro", cost: 8.00 },
  { name: "Canva Pro", cost: 12.99 },
  { name: "Hulu", cost: 7.99 },
  { name: "HBO Max", cost: 14.99 },
  { name: "Paramount+", cost: 5.99 },
  { name: "Peacock Premium", cost: 4.99 }
];

function showSuggestions(query) {
  const suggestions = document.getElementById("suggestions");
  const filtered = popularSubscriptions.filter(sub => 
    sub.name.toLowerCase().includes(query.toLowerCase())
  ).slice(0, 5);

  if (query.length > 0 && filtered.length > 0) {
    suggestions.innerHTML = filtered.map(sub => 
      `<div class="suggestion-item p-2 hover:bg-gray-100 cursor-pointer flex justify-between" data-name="${sub.name}" data-cost="${sub.cost}">
        <span>${sub.name}</span>
        <span class="text-gray-500">€${sub.cost}</span>
      </div>`
    ).join('');
    suggestions.classList.remove("hidden");
  } else {
    suggestions.classList.add("hidden");
  }
}

/* ---------------- Add a subscription ---------------- */
async function addSub(e) {
  e.preventDefault();
  const day = document.getElementById("nextDay").value;
  const month = document.getElementById("nextMonth").value;
  const currentYear = new Date().getFullYear();

  // Create date for current year, if past current date use next year
  let nextDate = new Date(currentYear, parseInt(month) - 1, parseInt(day));
  if (nextDate < new Date()) {
    nextDate = new Date(currentYear + 1, parseInt(month) - 1, parseInt(day));
  }

  const data = {
    name: document.getElementById("name").value,
    cost: parseFloat(document.getElementById("cost").value),
    cycle: document.getElementById("cycle").value,
    nextDate: nextDate.toISOString().split('T')[0],
  };
  await fetch("/api/subscriptions", {
    method: "POST",
    headers: { 
      "Content-Type": "application/json",
      ...getAuthHeaders()
    },
    body: JSON.stringify(data),
  });
  e.target.reset();
  document.getElementById("suggestions").classList.add("hidden");
  fetchSubs();
}

/* ---------------- Event wiring ---------------- */
document.getElementById("subForm").addEventListener("submit", addSub);
document.getElementById("payBtn").addEventListener("click", handlePay);

// Name input with suggestions
document.getElementById("name").addEventListener("input", (e) => {
  showSuggestions(e.target.value);
});

// Hide suggestions when clicking outside
document.addEventListener("click", (e) => {
  if (!e.target.closest("#name") && !e.target.closest("#suggestions")) {
    document.getElementById("suggestions").classList.add("hidden");
  }
});

// Handle suggestion clicks
document.addEventListener("click", (e) => {
  if (e.target.closest(".suggestion-item")) {
    const item = e.target.closest(".suggestion-item");
    const name = item.dataset.name;
    const cost = item.dataset.cost;

    document.getElementById("name").value = name;
    document.getElementById("cost").value = cost;
    document.getElementById("suggestions").classList.add("hidden");
  }
});

/* Auto-run toggle with feedback */
const auto = document.getElementById("autoRun");
auto.checked = localStorage.getItem(AUTO_KEY) === "true";
auto.onchange = () => {
  if (auto.checked) {
    showAutoRunModal();
  } else {
    localStorage.setItem(AUTO_KEY, "false");
    localStorage.removeItem("autoRunDate");
    showSuccessMessage("Auto-run disabled. You'll need to trigger USW manually.");
  }
};

function showAutoRunModal() {
  // Get suggested date based on subscription dates
  fetchSubs().then(({ subs }) => {
    const dates = subs.map(s => new Date(s.nextDate)).filter(d => !isNaN(d));
    const suggestedDate = dates.length > 0 ? 
      new Date(Math.min(...dates)).getDate() : 
      new Date().getDate();

    const modal = document.createElement('div');
    modal.className = 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50';
    modal.innerHTML = `
      <div class="bg-white p-6 rounded-lg shadow-xl max-w-md w-full mx-4">
        <h3 class="text-lg font-medium text-gray-900 mb-4">Setup Auto-Run</h3>
        <p class="text-gray-600 mb-4">Choose when to automatically run USW each month:</p>

        <div class="space-y-3 mb-6">
          <label class="flex items-center space-x-3">
            <input type="radio" name="autoType" value="subscription" class="text-indigo-600" checked>
            <span>On earliest subscription date (${suggestedDate}${getOrdinalSuffix(suggestedDate)} of each month)</span>
          </label>
          <label class="flex items-center space-x-3">
            <input type="radio" name="autoType" value="payday" class="text-indigo-600">
            <span>On a specific payday</span>
          </label>
        </div>

        <div id="payDayInput" class="mb-4 hidden">
          <label class="block text-sm font-medium text-gray-700 mb-1">Choose day of month:</label>
          <select id="payDaySelect" class="w-full border p-2 rounded">
            ${Array.from({length: 28}, (_, i) => 
              `<option value="${i+1}">${i+1}${getOrdinalSuffix(i+1)}</option>`
            ).join('')}
          </select>
        </div>

        <div class="flex justify-end space-x-3">
          <button id="cancelAutoRun" class="px-4 py-2 text-gray-600 hover:text-gray-800">Cancel</button>
          <button id="confirmAutoRun" class="bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700">Enable Auto-Run</button>
        </div>
      </div>
    `;

    document.body.appendChild(modal);

    // Handle radio button change
    modal.querySelectorAll('input[name="autoType"]').forEach(radio => {
      radio.addEventListener('change', () => {
        const payDayInput = document.getElementById('payDayInput');
        if (radio.value === 'payday') {
          payDayInput.classList.remove('hidden');
        } else {
          payDayInput.classList.add('hidden');
        }
      });
    });

    // Handle buttons
    document.getElementById('cancelAutoRun').addEventListener('click', () => {
      auto.checked = false;
      modal.remove();
    });

    document.getElementById('confirmAutoRun').addEventListener('click', () => {
      const selectedType = modal.querySelector('input[name="autoType"]:checked').value;
      const selectedDate = selectedType === 'subscription' ? 
        suggestedDate : 
        parseInt(document.getElementById('payDaySelect').value);

      localStorage.setItem(AUTO_KEY, "true");
      localStorage.setItem("autoRunDate", selectedDate.toString());
      localStorage.setItem("autoRunType", selectedType);

      const message = selectedType === 'subscription' ? 
        `Auto-run enabled for ${selectedDate}${getOrdinalSuffix(selectedDate)} of each month (earliest subscription date).` :
        `Auto-run enabled for ${selectedDate}${getOrdinalSuffix(selectedDate)} of each month (payday).`;

      showSuccessMessage(message);
      modal.remove();
    });
  });
}

function getOrdinalSuffix(day) {
  if (day > 3 && day < 21) return 'th';
  switch (day % 10) {
    case 1: return 'st';
    case 2: return 'nd';  
    case 3: return 'rd';
    default: return 'th';
  }
}

function showSuccessMessage(message) {
  const notification = document.createElement("div");
  notification.className = "fixed top-4 right-4 bg-green-500 text-white px-4 py-3 rounded-lg shadow-lg z-50";
  notification.textContent = message;
  document.body.appendChild(notification);

  setTimeout(() => {
    notification.remove();
  }, 3000);
}

/* -------------- Delete and Undo functionality -------------- */
document.addEventListener("click", async (e) => {
  if (e.target.classList.contains("delete-btn")) {
    const id = parseInt(e.target.dataset.id);

    // Get the subscription data before deleting
    const res = await fetch("/api/subscriptions");
    const subs = await res.json();
    const subToDelete = subs.find(sub => sub.id === id);

    if (subToDelete) {
      // Add to queue for potential undo
      deletedQueue.push(subToDelete);

      // Delete from server
      await fetch(`/api/subscriptions/${id}`, { method: "DELETE" });
      fetchSubs();

      // Show/update undo notification
      showUndoNotification();
    }
  }

  if (e.target.id === "undoBtn") {
    if (deletedQueue.length > 0) {
      // Restore the most recently deleted subscription
      const toRestore = deletedQueue.pop();

      await fetch("/api/subscriptions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: toRestore.name,
          cost: toRestore.cost,
          cycle: toRestore.cycle,
          nextDate: toRestore.nextDate
        }),
      });

      // Update or remove notification
      if (deletedQueue.length > 0) {
        showUndoNotification(); // Update to show remaining items
      } else {
        document.getElementById("undoNotification").remove();
        if (undoTimer) clearTimeout(undoTimer);
      }

      // Refresh the table
      fetchSubs();
    }
  }
});

// Update UI based on auth status
function updateUserUI() {
  const userInfo = document.getElementById('userInfo');
  const logoutBtn = document.getElementById('logoutBtn');
  const loginLink = document.getElementById('loginLink');

  if (isAuthenticated && userName) {
    const planBadge = isPremium ? 
      '<span class="ml-2 px-2 py-1 text-xs bg-yellow-500 text-white rounded">Premium</span>' : 
      '<span class="ml-2 px-2 py-1 text-xs bg-gray-500 text-white rounded">Free</span>';
    userInfo.innerHTML = `Welcome, ${userName}${planBadge}`;
    logoutBtn.classList.remove('hidden');
    loginLink.classList.add('hidden');
  } else {
    userInfo.textContent = 'Guest Mode';
    logoutBtn.classList.add('hidden');
    loginLink.classList.remove('hidden');
  }
}

// Logout functionality
document.getElementById('logoutBtn')?.addEventListener('click', () => {
  localStorage.removeItem('authToken');
  localStorage.removeItem('userName');
  localStorage.removeItem('userEmail');
  localStorage.removeItem('userPlan');
  window.location.href = 'index.html';
});

fetchSubs();
updateRunInfo();
updateUserUI();
/* ------------- End of patched script.js ------------- */