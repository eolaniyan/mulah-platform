const express = require('express');
const app = express();
const PORT = process.env.PORT || 3000;
app.use(express.json());
app.use(express.static('public'));

// In-memory storage (for demo purposes)
let users = [
  {
    id: 1,
    name: 'Free User Demo',
    email: 'free@demo.com',
    password: 'demo123',
    plan: 'free',
    token: null,
    createdAt: '2025-01-01T00:00:00.000Z'
  },
  {
    id: 2,
    name: 'Premium User Demo',
    email: 'premium@demo.com',
    password: 'demo123',
    plan: 'premium',
    token: null,
    createdAt: '2025-01-01T00:00:00.000Z'
  },
  {
    id: 3,
    name: 'Free Heavy User',
    email: 'freeheavy@demo.com',
    password: 'demo123',
    plan: 'free',
    token: null,
    createdAt: '2025-01-01T00:00:00.000Z'
  },
  {
    id: 4,
    name: 'Premium Light User',
    email: 'premiumlight@demo.com',
    password: 'demo123',
    plan: 'premium',
    token: null,
    createdAt: '2025-01-01T00:00:00.000Z'
  }
];

let subscriptions = [
  // Free User Demo (2 subscriptions)
  { id: 1, name: 'Netflix', cost: 12.99, cycle: 'monthly', nextDate: '2025-02-05', userId: 1 },
  { id: 2, name: 'Spotify', cost: 9.99, cycle: 'monthly', nextDate: '2025-02-08', userId: 1 },
  
  // Premium User Demo (8 subscriptions - heavy usage)
  { id: 3, name: 'Netflix', cost: 15.49, cycle: 'monthly', nextDate: '2025-02-03', userId: 2 },
  { id: 4, name: 'Disney+', cost: 7.99, cycle: 'monthly', nextDate: '2025-02-10', userId: 2 },
  { id: 5, name: 'Adobe Creative Suite', cost: 52.99, cycle: 'monthly', nextDate: '2025-02-15', userId: 2 },
  { id: 6, name: 'GitHub Pro', cost: 4.00, cycle: 'monthly', nextDate: '2025-02-12', userId: 2 },
  { id: 7, name: 'Figma Pro', cost: 12.00, cycle: 'monthly', nextDate: '2025-02-18', userId: 2 },
  { id: 8, name: 'Notion Pro', cost: 8.00, cycle: 'monthly', nextDate: '2025-02-20', userId: 2 },
  { id: 9, name: 'Dropbox Plus', cost: 9.99, cycle: 'monthly', nextDate: '2025-02-22', userId: 2 },
  { id: 10, name: 'Canva Pro', cost: 12.99, cycle: 'monthly', nextDate: '2025-02-25', userId: 2 },
  
  // Free Heavy User (6 subscriptions - would benefit from premium)
  { id: 11, name: 'Netflix', cost: 12.99, cycle: 'monthly', nextDate: '2025-02-07', userId: 3 },
  { id: 12, name: 'Spotify', cost: 9.99, cycle: 'monthly', nextDate: '2025-02-09', userId: 3 },
  { id: 13, name: 'YouTube Premium', cost: 11.99, cycle: 'monthly', nextDate: '2025-02-11', userId: 3 },
  { id: 14, name: 'Amazon Prime', cost: 8.99, cycle: 'monthly', nextDate: '2025-02-13', userId: 3 },
  { id: 15, name: 'Apple iCloud+', cost: 2.99, cycle: 'monthly', nextDate: '2025-02-15', userId: 3 },
  { id: 16, name: 'Hulu', cost: 7.99, cycle: 'monthly', nextDate: '2025-02-17', userId: 3 },
  
  // Premium Light User (2 subscriptions - not using premium fully)
  { id: 17, name: 'Spotify', cost: 9.99, cycle: 'monthly', nextDate: '2025-02-14', userId: 4 },
  { id: 18, name: 'Netflix', cost: 12.99, cycle: 'monthly', nextDate: '2025-02-16', userId: 4 }
];

// Simple token generation (in production, use proper JWT)
function generateToken() {
  return Math.random().toString(36).substr(2) + Date.now().toString(36);
}

// Get user from token
function getUserFromToken(token) {
  return users.find(user => user.token === token);
}
// Auth routes
app.post('/api/auth/register', (req, res) => {
  const { name, email, password } = req.body;
  
  // Check if user already exists
  if (users.find(user => user.email === email)) {
    return res.status(400).json({ error: 'User already exists' });
  }
  
  // Create new user
  const token = generateToken();
  const user = {
    id: users.length + 1,
    name,
    email,
    password, // In production, hash this!
    token,
    createdAt: new Date().toISOString()
  };
  
  users.push(user);
  
  res.status(201).json({
    token,
    user: { id: user.id, name: user.name, email: user.email, plan: user.plan || 'free' }
  });
});

app.post('/api/auth/login', (req, res) => {
  const { email, password } = req.body;
  
  const user = users.find(u => u.email === email && u.password === password);
  
  if (!user) {
    return res.status(401).json({ error: 'Invalid credentials' });
  }
  
  // Generate new token for this session
  user.token = generateToken();
  
  res.json({
    token: user.token,
    user: { id: user.id, name: user.name, email: user.email, plan: user.plan || 'free' }
  });
});

app.get('/api/subscriptions', (req, res) => {
  const token = req.headers.authorization?.replace('Bearer ', '');
  const user = getUserFromToken(token);
  
  // Return user-specific subscriptions for authenticated users
  if (!user) {
    res.json([]);
  } else {
    res.json(subscriptions.filter(sub => sub.userId === user.id));
  }
});
app.post('/api/subscriptions', (req, res) => {
  const { name, cost, cycle, nextDate } = req.body;
  const token = req.headers.authorization?.replace('Bearer ', '');
  const user = getUserFromToken(token);
  
  const id = subscriptions.length ? subscriptions[subscriptions.length - 1].id + 1 : 1;
  const subscription = {
    id,
    name,
    cost: Number(cost),
    cycle,
    nextDate,
    userId: user ? user.id : null
  };
  
  subscriptions.push(subscription);
  res.status(201).json({ id });
});

app.delete('/api/subscriptions/:id', (req, res) => {
  const id = parseInt(req.params.id);
  const index = subscriptions.findIndex(sub => sub.id === id);
  if (index !== -1) {
    subscriptions.splice(index, 1);
    res.status(200).json({ message: 'Subscription deleted' });
  } else {
    res.status(404).json({ error: 'Subscription not found' });
  }
});

app.listen(PORT, () => console.log('SubSync v2 running on port', PORT));