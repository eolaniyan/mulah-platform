# log_setup.py  – Production-ready logging for Finance MVP
from pathlib import Path
import logging
from logging.handlers import RotatingFileHandler

from fastapi import Request
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware

# ---------- log directory ----------
LOG_DIR = Path("logs")
LOG_DIR.mkdir(exist_ok=True)

# ---------- root logger ----------
logger = logging.getLogger("finance_app")
logger.setLevel(logging.INFO)

# ---------- plain-text log (app.log) ----------
plain_handler = RotatingFileHandler(
    LOG_DIR / "app.log",   # logs/app.log
    maxBytes=5 * 1024 * 1024,  # 5 MB
    backupCount=3
)
plain_fmt = logging.Formatter(
    "[%(asctime)s] %(levelname)s in %(module)s: %(message)s"
)
plain_handler.setFormatter(plain_fmt)
logger.addHandler(plain_handler)

# ---------- JSON log (app.json) ----------
try:
    from pythonjsonlogger import jsonlogger

    json_handler = RotatingFileHandler(
        LOG_DIR / "app.json",   # logs/app.json
        maxBytes=5 * 1024 * 1024,
        backupCount=3
    )
    json_fmt = jsonlogger.JsonFormatter(
        "%(asctime)s %(levelname)s %(name)s %(module)s %(message)s"
    )
    json_handler.setFormatter(json_fmt)
    logger.addHandler(json_handler)
except ImportError:
    # If python-json-logger isn't installed, skip the JSON handler
    logger.warning("python-json-logger not installed; JSON logs disabled")

# ---------- FastAPI middleware for per-request logging ----------
class LoggingMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        logger.info("Request  %s %s", request.method, request.url.path)
        response = await call_next(request)
        logger.info("Response %s %s", request.method, response.status_code)
        return response

# ---------- global exception handler ----------
def install_exception_handler(app):
    @app.exception_handler(Exception)
    async def prod_exception_handler(request: Request, exc: Exception):
        logger.exception("Unhandled error")
        return JSONResponse(
            status_code=500,
            content={"detail": "Internal server error. Please try again later."},
        )
