from datetime import datetime, timedelta
from typing import Optional, List, Dict
import uuid, random, statistics, numpy as np
from log_setup import logger, LoggingMiddleware, install_exception_handler
from pythonjsonlogger import jsonlogger
from fastapi import Request, HTTPException
from log_setup import logger
from fastapi.responses import JSONResponse

from fastapi import FastAPI, HTTPException, Body, UploadFile, File, Form
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from sqlmodel import SQLModel, Field, Session, create_engine, select

# ---- db engine first
engine = create_engine("sqlite:///finance.db", echo=False)

# ---- models
class User(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    user_id: str = Field(index=True, unique=True)

class Transaction(SQLModel, table=True):
    id: str = Field(primary_key=True)
    user_id: str = Field(index=True)  # Index for user queries
    date: datetime = Field(index=True)  # Index for date range queries
    amount: float
    description: str
    merchant: str = Field(index=True)  # Index for recurring payment detection
    category: Optional[str] = Field(default=None, index=True)  # Index for category queries
    enriched: bool = False
    # NEW columns
    is_recurring: Optional[bool] = None
    iso_week: Optional[int] = None
    month: Optional[str] = Field(default=None, index=True)  # Index for monthly reports

class Budget(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    user_id: str = Field(index=True)
    category: str = Field(index=True)
    monthly_limit: float
    created_date: datetime = Field(default_factory=datetime.utcnow)

class Goal(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    user_id: str = Field(index=True)
    title: str
    target_amount: float
    current_amount: float = 0
    target_date: datetime
    goal_type: str  # 'savings', 'spending_reduction', 'emergency_fund'
    category: Optional[str] = None
    created_date: datetime = Field(default_factory=datetime.utcnow)
    achieved: bool = False

# ---- create tables *after* models exist
SQLModel.metadata.create_all(engine)

# ---- FastAPI app & static
app = FastAPI(title="Finance MVP v5")
app.add_middleware(LoggingMiddleware)  # ↩️  request/response logs
install_exception_handler(app) # ↩️  global error catcher
app.mount("/frontend", StaticFiles(directory="frontend"), name="frontend")


@app.get("/", include_in_schema=False)
def web_root():
    return FileResponse("frontend/index.html")

@app.exception_handler(HTTPException)
async def http_exception_logger(request: Request, exc: HTTPException):
    logger.warning(
        f"HTTPException {exc.status_code} on {request.method} "
        f"{request.url.path}: {exc.detail}"
    )
    return JSONResponse(status_code=exc.status_code, content={"detail": exc.detail})

# ---- helpers
CATEGORY_KEYWORDS = {
    "Transport - Fuel": ["fuel", "diesel", "gas", "unleaded", "petrol", "bp", "shell", "texaco", "esso", "circle k", "applegreen", "topaz", "maxol"],
    "Groceries": ["aldi", "tesco", "lidl", "spar", "grocery", "supermarket", "asda", "sainsbury", "morrisons", "centra", "supervalu", "whole foods"],
    "Transport - Ride": ["uber", "bolt", "taxi", "lyft", "cabify", "transport", "bus", "train", "luas", "dublin bus", "bike"],
    "Subscriptions": ["netflix", "spotify", "prime", "apple music", "youtube premium", "disney+", "hulu", "subscription", "monthly"],
    "Dining": ["restaurant", "cafe", "food", "burger", "kfc", "mcd", "mcdonalds", "starbucks", "costa", "dominos", "pizza", "takeaway", "ramen"],
    "Shopping": ["amazon", "store", "shop", "mall", "ebay", "etsy", "clothing", "electronics", "apple store", "zara", "h&m", "ikea"],
    "Bills & Utilities": ["electric", "gas bill", "water", "internet", "phone", "utility", "council tax", "broadband", "mobile", "insurance"],
    "Healthcare": ["pharmacy", "doctor", "hospital", "dental", "medical", "health", "clinic", "boots"],
    "Entertainment": ["cinema", "movie", "theatre", "concert", "game", "steam", "gym", "fitness", "planet fitness", "netflix"],
    "Auto & Services": ["bmw", "tesla", "car", "service", "repair", "mechanic", "insurance", "supercharger", "parking"],
    "Education": ["school", "college", "university", "course", "books", "student", "library", "tuition"]
}

# Merchant normalization patterns
MERCHANT_PATTERNS = {
    r'AMZN\*.*': 'Amazon',
    r'AMAZON\*.*': 'Amazon',
    r'SQ \*.*': 'Square Payment',
    r'PAYPAL \*.*': 'PayPal',
    r'GOOGLE\*.*': 'Google',
    r'APPLE\.COM/BILL.*': 'Apple',
    r'TST\* .*': 'Toast POS',
    r'UBER\s+.*': 'Uber',
    r'SP\s+.*': 'Spotify',
    r'NETFLIX\.COM.*': 'Netflix'
}

def ml_categorize(tx: Transaction) -> str:
    text = f"{tx.description} {tx.merchant}".lower()
    scores = {}

    # Calculate keyword match scores
    for cat, kws in CATEGORY_KEYWORDS.items():
        scores[cat] = 0
        for kw in kws:
            if kw in text:
                # Give higher score for exact merchant matches
                if kw in tx.merchant.lower():
                    scores[cat] += 2
                else:
                    scores[cat] += 1

    # If no keyword matches, try merchant-based rules
    if not any(scores.values()):
        merchant_lower = tx.merchant.lower()
        if any(word in merchant_lower for word in ['market', 'grocery', 'food']):
            return "Groceries"
        elif any(word in merchant_lower for word in ['fuel', 'gas', 'petrol']):
            return "Transport - Fuel"
        elif any(word in merchant_lower for word in ['restaurant', 'cafe', 'pizza']):
            return "Dining"
        else:
            return "Misc"

    # Return category with highest score
    best_cat = max(scores, key=scores.get)
    return best_cat if scores[best_cat] > 0 else "Misc"

# --- Helper: auto-category wrapper (can evolve into ML model) -------------
def auto_category(description: str) -> str:
    """
    Thin wrapper around ml_categorize() that accepts raw text.
    Later you can swap this out for a transformer or 3-shot prompt.
    """
    dummy_tx = Transaction(
        id="tmp",
        user_id="tmp",
        date=datetime.utcnow(),
        amount=0,
        description=description,
        merchant=description  # reuse field for keyword scan
    )
    return ml_categorize(dummy_tx)

# -------------------------------------------------------------------------
# Helper: normalise merchant & detect recurring payments
# -------------------------------------------------------------------------
from collections import Counter

def normalise_merchant(name: str) -> str:
    """Normalize merchant names with pattern matching and cleaning."""
    import re

    # First apply pattern-based normalization
    for pattern, replacement in MERCHANT_PATTERNS.items():
        if re.match(pattern, name, re.IGNORECASE):
            return replacement

    # Clean up the merchant name
    # Remove common prefixes/suffixes
    cleaned = re.sub(r'^(POS|TST|SQ)\s*\*?\s*', '', name, flags=re.IGNORECASE)
    cleaned = re.sub(r'\s+(POS|PAYMENT|PAY)$', '', cleaned, flags=re.IGNORECASE)

    # Remove special characters but keep important ones
    cleaned = re.sub(r'[^\w\s&\-\.]', ' ', cleaned)

    # Collapse multiple spaces and title case
    cleaned = " ".join(cleaned.split()).title()

    return cleaned if cleaned else name

def is_recurring(user_id: str, merchant: str, session) -> bool:
    """Recurring if ≥3 payments to same merchant in the last 60 days."""
    try:
        cutoff = datetime.utcnow() - timedelta(days=60)
        q = select(Transaction).where(
                Transaction.user_id == user_id,
                Transaction.merchant == merchant,
                Transaction.date >= cutoff)
        result = session.exec(q).all()
        return len(result) >= 2  # already 2 in DB → this is the 3rd
    except Exception as e:
        logger.warning(f"Error checking recurring status: {e}")
        return False

def daily_totals(transactions: List[Transaction]) -> Dict[str, float]:
    totals={}
    for t in transactions:
        d = t.date.strftime("%Y-%m-%d")
        totals[d]=totals.get(d,0)+abs(t.amount)
    return totals

def forecast_balance(user_id:str):
    if not user_id or not isinstance(user_id, str):
        return {"message": "Invalid user_id"}

    try:
        with Session(engine) as session:
            txns = session.exec(select(Transaction).where(Transaction.user_id==user_id)).all()
    except Exception as e:
        logger.error(f"Database error in forecast_balance: {e}")
        return {"message": "Database error"}

    if not txns:
        return {"message":"No data"}
    totals = daily_totals(txns)
    # Convert to ordered list last 14 days
    days = sorted(totals.keys())[-14:]
    if len(days)<2:
        return {"message":"Not enough data"}
    y = [totals[d] for d in days]
    x = list(range(len(y)))

    try:
        slope, intercept = np.polyfit(x, y, 1)
        # predict next 7 days spend
        pred_next = [slope*(len(y)+i)+intercept for i in range(1,8)]
        prediction = float(sum(pred_next))
        return {
            "last14": y,
            "predicted_next7_total": round(prediction,2)
        }
    except Exception as e:
        logger.error(f"Error in forecast calculation: {e}")
        return {"message": "Forecast calculation failed"}

def chart_data(user_id:str):
    if not user_id or not isinstance(user_id, str):
        return {"daily":[], "category":{}, "month":{}}

    try:
        with Session(engine) as session:
            txns = session.exec(select(Transaction).where(Transaction.user_id==user_id)).all()
    except Exception as e:
        logger.error(f"Database error in chart_data: {e}")
        return {"daily":[], "category":{}, "month":{}}

    if not txns:
        return {"daily":[], "category":{}, "month":{}}
    # daily totals last 30 days
    cutoff = datetime.utcnow() - timedelta(days=30)
    day_tot={}
    cat_tot={}
    month_tot={}
    for t in txns:
        if t.date < cutoff:
            continue
        day = t.date.strftime("%Y-%m-%d")
        day_tot[day]=day_tot.get(day,0)+abs(t.amount)
        if t.category:
            cat_tot[t.category]=cat_tot.get(t.category,0)+abs(t.amount)
        month = t.date.strftime("%Y-%m")
        month_tot[month]=month_tot.get(month,0)+abs(t.amount)
    daily = [{"date":d,"total":round(v,2)} for d,v in sorted(day_tot.items())]
    return {"daily":daily, "category":cat_tot, "month":month_tot}

# ---- schema
from pydantic import BaseModel
class RegisterPayload(BaseModel): user_id:str
class LoginPayload(BaseModel): user_id:str
class SyncItem(BaseModel):
    id:str
    date:datetime
    amount:float
    description:str
    merchant:str
class SyncPayload(BaseModel):
    user_id:str
    transactions:List[SyncItem]
class ClassifyPayload(BaseModel):
    user_id:str
class CsvUpload(BaseModel): user_id:str

class BudgetPayload(BaseModel):
    user_id: str
    category: str
    monthly_limit: float

class GoalPayload(BaseModel):
    user_id: str
    title: str
    target_amount: float
    target_date: datetime
    goal_type: str
    category: Optional[str] = None

# ---- endpoints
@app.post("/register")
def register(p:RegisterPayload):
    with Session(engine) as s:
        if s.exec(select(User).where(User.user_id==p.user_id)).first():
            raise HTTPException(400,"Exists")
        s.add(User(user_id=p.user_id)); s.commit()
    return {"msg":"registered"}

@app.post("/login")
def login(p:LoginPayload):
    with Session(engine) as s:
        if not s.exec(select(User).where(User.user_id==p.user_id)).first():
            raise HTTPException(404,"no user")
    return {"msg":"ok"}

@app.post("/sync")
def sync(payload: SyncPayload):
    with Session(engine) as s:
        # 0) Ensure user exists
        if not s.exec(select(User).where(User.user_id == payload.user_id)).first():
            raise HTTPException(status_code=404,
                                detail=f"User {payload.user_id} not found")

        tx_objects = []
        errors = []
        seen_ids_db = {row[0] for row in s.exec(select(Transaction.id)).all()}
        seen_ids_batch = set()  # Track IDs within this batch

        for i, tx in enumerate(payload.transactions):
            try:
                data = tx.dict()
                data["user_id"] = payload.user_id  # inject if missing

                # -------- Validation --------
                if not data.get("id") or not isinstance(data["id"], str) or not data["id"].strip():
                    raise ValueError("Transaction ID is required and must be a non-empty string")
                if data["id"] in seen_ids_db:
                    raise ValueError("Duplicate transaction id (already in database)")
                if data["id"] in seen_ids_batch:
                    raise ValueError("Duplicate transaction id (within current batch)")
                seen_ids_batch.add(data["id"])

                if not data.get("description") or not isinstance(data["description"], str) or not data["description"].strip():
                    raise ValueError("Description is required and must be a non-empty string")
                if not data.get("merchant") or not isinstance(data["merchant"], str) or not data["merchant"].strip():
                    raise ValueError("Merchant is required and must be a non-empty string")
                try:
                    amount = float(data["amount"])
                    if amount == 0:
                        raise ValueError("Amount cannot be zero")
                    if abs(amount) > 1000000:  # Sanity check for very large amounts
                        raise ValueError("Amount too large")
                    data["amount"] = amount
                except (ValueError, TypeError):
                    raise ValueError("Invalid amount format")

                try:
                    tx_date = datetime.fromisoformat(str(data["date"]).replace('Z', '+00:00'))
                except ValueError:
                    raise ValueError("Invalid date format")

                # Convert to naive datetime for comparison with utcnow()
                tx_date_naive = tx_date.replace(tzinfo=None) if tx_date.tzinfo else tx_date
                if tx_date_naive > datetime.utcnow() + timedelta(days=1):
                    raise ValueError("Future date not allowed")

                # -------- Enrichment --------
                data["date"] = tx_date_naive  # Store naive datetime
                data["merchant"] = normalise_merchant(data["merchant"])
                data["category"] = auto_category(data["description"])
                data["enriched"] = True

                # Safe call to is_recurring with error handling
                data["is_recurring"] = is_recurring(payload.user_id, data["merchant"], s)

                data["iso_week"] = tx_date_naive.isocalendar().week
                data["month"] = tx_date_naive.strftime("%Y-%m")

                tx_objects.append(Transaction(**data))

            except Exception as e:
                errors.append(f"Tx #{i}: {e}")

        # Check for errors and return early if any exist
        if errors:
            logger.error(f"SYNC validation errors for {payload.user_id}: {errors}")
            return JSONResponse(
                status_code=400,
                content={
                    "status": "error",
                    "message": f"{len(errors)} transactions failed validation",
                    "errors": errors,
                },
            )

        # Add all validated transactions to the database
        for tx in tx_objects:
            s.add(tx)
        s.commit()

        return {
            "status": "success",
            "message": f"Synced {len(tx_objects)} transactions",
            "synced_count": len(tx_objects)
        }

@app.get("/export")
def export_data(user_id: str):
    """Export user's transaction data as JSON"""
    if not user_id or not isinstance(user_id, str):
        raise HTTPException(400, "Invalid user_id")

    with Session(engine) as s:
        # Verify user exists
        if not s.exec(select(User).where(User.user_id == user_id)).first():
            raise HTTPException(404, "User not found")

        txns = s.exec(select(Transaction).where(Transaction.user_id == user_id)).all()

        export_data = []
        for tx in txns:
            export_data.append({
                "id": tx.id,
                "date": tx.date.isoformat(),
                "amount": tx.amount,
                "description": tx.description,
                "merchant": tx.merchant,
                "category": tx.category,
                "is_recurring": tx.is_recurring
            })

        return {
            "user_id": user_id,
            "export_date": datetime.utcnow().isoformat(),
            "transaction_count": len(export_data),
            "transactions": export_data
        }


@app.get("/transactions")
def get_transactions(user_id: str, limit: int = 50, search: str = ""):
    """Get paginated transaction history with search"""
    if not user_id or not isinstance(user_id, str):
        raise HTTPException(400, "Invalid user_id")

    with Session(engine) as s:
        # Verify user exists
        if not s.exec(select(User).where(User.user_id == user_id)).first():
            raise HTTPException(404, "User not found")

        query = select(Transaction).where(Transaction.user_id == user_id)

        # Add search filter if provided
        if search:
            search_term = f"%{search}%"
            query = query.where(
                Transaction.merchant.ilike(search_term) |
                Transaction.description.ilike(search_term) |
                Transaction.category.ilike(search_term)
            )

        # Order by date descending and limit
        query = query.order_by(Transaction.date.desc()).limit(limit)

        txns = s.exec(query).all()

        transactions = []
        for tx in txns:
            transactions.append({
                "id": tx.id,
                "date": tx.date.isoformat(),
                "amount": tx.amount,
                "description": tx.description,
                "merchant": tx.merchant,
                "category": tx.category,
                "is_recurring": tx.is_recurring
            })

        return {
            "user_id": user_id,
            "transactions": transactions,
            "count": len(transactions),
            "search": search
        }

@app.get("/insights")
def get_insights(user_id: str, period: str = "30d"):
    """Get enhanced spending insights with alerts and analysis for specific period"""
    if not user_id or not isinstance(user_id, str):
        raise HTTPException(400, "Invalid user_id")

    with Session(engine) as s:
        # Verify user exists
        if not s.exec(select(User).where(User.user_id == user_id)).first():
            raise HTTPException(404, "User not found")

        # Parse period and filter transactions
        period_days = {
            "30d": 30, "60d": 60, "90d": 90, "6m": 180, "1y": 365
        }
        days = period_days.get(period, 30)
        cutoff = datetime.utcnow() - timedelta(days=days)

        all_txns = s.exec(select(Transaction).where(Transaction.user_id == user_id)).all()
        txns = [tx for tx in all_txns if tx.date >= cutoff]

        if not txns:
            return {"message": f"No transactions found for {period}"}

        # Calculate insights
        total_spend = sum(abs(tx.amount) for tx in txns)
        avg_transaction = total_spend / len(txns) if txns else 0

        # Most frequent merchant by transaction count and by amount
        merchant_counts = {}
        merchant_amounts = {}
        category_amounts = {}

        for tx in txns:
            merchant_counts[tx.merchant] = merchant_counts.get(tx.merchant, 0) + 1
            merchant_amounts[tx.merchant] = merchant_amounts.get(tx.merchant, 0) + abs(tx.amount)
            if tx.category:
                category_amounts[tx.category] = category_amounts.get(tx.category, 0) + abs(tx.amount)

        most_frequent_merchant = max(merchant_counts, key=merchant_counts.get) if merchant_counts else "None"
        top_spending_merchant = max(merchant_amounts, key=merchant_amounts.get) if merchant_amounts else "None"
        top_category = max(category_amounts, key=category_amounts.get) if category_amounts else "None"

        # Largest transaction
        largest_tx = max(txns, key=lambda x: abs(x.amount)) if txns else None

        # Recurring payments
        recurring_count = sum(1 for tx in txns if tx.is_recurring)

        # Monthly spend analysis
        monthly_spend = {}
        weekly_spend = {}
        for tx in txns:
            month = tx.date.strftime("%Y-%m")
            week = f"{tx.date.strftime('%Y')}-W{tx.iso_week}"
            monthly_spend[month] = monthly_spend.get(month, 0) + abs(tx.amount)
            weekly_spend[week] = weekly_spend.get(week, 0) + abs(tx.amount)

        # Calculate proper averages
        current_month = datetime.utcnow().strftime("%Y-%m")
        this_month_spend = monthly_spend.get(current_month, 0)
        avg_monthly_spend = sum(monthly_spend.values()) / len(monthly_spend) if monthly_spend else 0

        # Weekly spending pattern analysis
        recent_weeks = sorted(weekly_spend.keys())[-4:] if len(weekly_spend) >= 4 else sorted(weekly_spend.keys())
        recent_weekly_avg = sum(weekly_spend.get(w, 0) for w in recent_weeks) / len(recent_weeks) if recent_weeks else 0

        # Day of week spending analysis
        weekday_spend = {}
        for tx in txns:
            weekday = tx.date.strftime("%A")
            weekday_spend[weekday] = weekday_spend.get(weekday, 0) + abs(tx.amount)

        peak_spending_day = max(weekday_spend, key=weekday_spend.get) if weekday_spend else "None"

        # Category trend analysis
        category_trends = {}
        for cat, amount in category_amounts.items():
            cat_txns = [tx for tx in txns if tx.category == cat]
            if len(cat_txns) >= 3:
                recent_cat = sum(abs(tx.amount) for tx in cat_txns[-len(cat_txns)//2:])
                older_cat = sum(abs(tx.amount) for tx in cat_txns[:len(cat_txns)//2])
                if older_cat > 0:
                    trend = (recent_cat - older_cat) / older_cat * 100
                    category_trends[cat] = trend

        # Generate period-aware insights with tooltips and priorities
        insights = []

        # Period-specific analysis
        period_name = {
            "30d": "last month", "60d": "last 2 months", "90d": "last 3 months", 
            "6m": "last 6 months", "1y": "last year"
        }.get(period, f"last {days} days")

        # 1. High spending alert (HIGH PRIORITY)
        if this_month_spend > avg_monthly_spend * 1.2:
            insights.append({
                "text": f"⚠️ This month's spending (€{this_month_spend:.0f}) is {((this_month_spend/avg_monthly_spend-1)*100):.0f}% above your average",
                "tooltip": f"Your spending this month is significantly higher than your average of €{avg_monthly_spend:.0f}. Consider reviewing recent purchases and adjusting your budget to avoid overspending.",
                "priority": 1,
                "type": "alert"
            })

        # 2. Category trend analysis (MEDIUM PRIORITY)
        significant_trends = [(cat, trend) for cat, trend in category_trends.items() if abs(trend) > 30]
        if significant_trends:
            cat, trend = max(significant_trends, key=lambda x: abs(x[1]))
            direction = "increased" if trend > 0 else "decreased"
            insights.append({
                "text": f"📊 {cat} spending {direction} by {abs(trend):.0f}% in {period_name}",
                "tooltip": f"Your {cat} spending pattern has changed significantly. {'Consider if this aligns with your budget goals and if its sustainable.' if trend > 0 else 'Great job reducing spending in this category!'}",
                "priority": 2,
                "type": "trend"
            })

        # 3. Spending concentration risk (MEDIUM PRIORITY)
        top_merchant_spend = merchant_amounts.get(top_spending_merchant, 0)
        if top_merchant_spend > total_spend * 0.3:
            insights.append({
                "text": f"🏪 {(top_merchant_spend/total_spend*100):.0f}% of spending is at {top_spending_merchant}",
                "tooltip": f"You have high spending concentration at one merchant (€{top_merchant_spend:.0f}). Consider diversifying your spending or negotiating better rates if it's a subscription.",
                "priority": 2,
                "type": "concentration"
            })

        # 4. Recurring payments insight (LOW PRIORITY)
        recurring_spend = sum(abs(tx.amount) for tx in txns if tx.is_recurring)
        if recurring_spend > total_spend * 0.25:
            insights.append({
                "text": f"🔄 {(recurring_spend/total_spend*100):.0f}% spending on recurring payments (€{recurring_spend:.0f})",
                "tooltip": f"Recurring payments make up a significant portion of your spending. Review these monthly to cancel unused subscriptions and ensure you're getting value for money.",
                "priority": 3,
                "type": "recurring"
            })

        # 5. Period-specific insights
        if days <= 30:  # Short-term insights
            # Weekly pattern
            if recent_weekly_avg > 0:
                current_week = f"{datetime.utcnow().strftime('%Y')}-W{datetime.utcnow().isocalendar().week}"
                current_week_spend = weekly_spend.get(current_week, 0)
                if current_week_spend > recent_weekly_avg * 1.3:
                    insights.append({
                        "text": f"📈 This week's spending (€{current_week_spend:.0f}) is trending high",
                        "tooltip": f"Your weekly spending is {((current_week_spend/recent_weekly_avg-1)*100):.0f}% above your recent average of €{recent_weekly_avg:.0f}. Consider postponing non-essential purchases.",
                        "priority": 1,
                        "type": "weekly_alert"
                    })

        elif days >= 180:  # Long-term insights
            # Seasonal patterns
            if len(monthly_spend) >= 3:
                monthly_values = list(monthly_spend.values())
                recent_avg = sum(monthly_values[-3:]) / 3
                older_avg = sum(monthly_values[:-3]) / len(monthly_values[:-3]) if len(monthly_values) > 3 else recent_avg
                if recent_avg > older_avg * 1.15:
                    insights.append({
                        "text": f"📈 Spending trend increasing over {period_name}",
                        "tooltip": f"Your spending has increased by {((recent_avg/older_avg-1)*100):.0f}% in recent months. Consider setting stricter budget limits or reviewing your spending categories.",
                        "priority": 2,
                        "type": "long_term_trend"
                    })

        # 6. Peak spending day insight (LOW PRIORITY)
        if peak_spending_day != "None":
            peak_amount = weekday_spend[peak_spending_day]
            insights.append({
                "text": f"📅 You spend most on {peak_spending_day}s (€{peak_amount:.0f} total)",
                "tooltip": f"Your highest spending day is {peak_spending_day}. Plan your weekly budget accordingly and be mindful of impulse purchases on this day.",
                "priority": 3,
                "type": "pattern"
            })

        # Sort by priority and limit to top 3
        insights.sort(key=lambda x: x["priority"])
        top_insights = insights[:3]

        return {
            "user_id": user_id,
            "period": period,
            "period_name": period_name,
            "total_transactions": len(txns),
            "total_spend": round(total_spend, 2),
            "avg_transaction": round(avg_transaction, 2),
            "most_frequent_merchant": most_frequent_merchant,
            "top_spending_merchant": top_spending_merchant,
            "top_category": top_category,
            "this_month_spend": round(this_month_spend, 2),
            "avg_monthly_spend": round(avg_monthly_spend, 2),
            "peak_spending_day": peak_spending_day,
            "recent_weekly_avg": round(recent_weekly_avg, 2),
            "largest_transaction": {
                "amount": largest_tx.amount,
                "merchant": largest_tx.merchant,
                "date": largest_tx.date.isoformat()
            } if largest_tx else None,
            "recurring_payments": recurring_count,
            "monthly_spend": monthly_spend,
            "weekly_spend": weekly_spend,
            "weekday_spend": weekday_spend,
            "category_trends": category_trends,
            "insights": top_insights,
            "category_breakdown": category_amounts
        }

@app.get("/transactions/month")
def get_transactions_by_month(user_id: str, month: str, limit: int = 100):
    """Get transactions for a specific month (format: YYYY-MM)"""
    if not user_id or not isinstance(user_id, str):
        raise HTTPException(400, "Invalid user_id")

    try:
        # Validate month format
        datetime.strptime(month, "%Y-%m")
    except ValueError:
        raise HTTPException(400, "Invalid month format. Use YYYY-MM")

    with Session(engine) as s:
        # Verify user exists
        if not s.exec(select(User).where(User.user_id == user_id)).first():
            raise HTTPException(404, "User not found")

        query = select(Transaction).where(
            Transaction.user_id == user_id,
            Transaction.month == month
        ).order_by(Transaction.date.desc()).limit(limit)

        txns = s.exec(query).all()

        transactions = []
        total_amount = 0
        for tx in txns:
            transactions.append({
                "id": tx.id,
                "date": tx.date.isoformat(),
                "amount": tx.amount,
                "description": tx.description,
                "merchant": tx.merchant,
                "category": tx.category,
                "is_recurring": tx.is_recurring
            })
            total_amount += abs(tx.amount)

        return {
            "user_id": user_id,
            "month": month,
            "transactions": transactions,
            "count": len(transactions),
            "total_amount": round(total_amount, 2)
        }

@app.post("/seed-users")
def seed_demo_users():
    """Create demo users with realistic data patterns"""
    demo_users = ["emmano21", "user123", "student_jane"]

    with Session(engine) as s:
        for user_id in demo_users:
            # Check if user already exists
            existing = s.exec(select(User).where(User.user_id == user_id)).first()
            if not existing:
                s.add(User(user_id=user_id))
        s.commit()

    return {
        "message": f"Created {len(demo_users)} demo users",
        "users": demo_users
    }

@app.post("/budgets")
def create_budget(payload: BudgetPayload):
    """Create or update budget for a category"""
    with Session(engine) as s:
        # Check if user exists
        if not s.exec(select(User).where(User.user_id == payload.user_id)).first():
            raise HTTPException(404, "User not found")
        
        # Check if budget already exists for this category
        existing = s.exec(
            select(Budget).where(
                Budget.user_id == payload.user_id,
                Budget.category == payload.category
            )
        ).first()
        
        if existing:
            existing.monthly_limit = payload.monthly_limit
            s.add(existing)
        else:
            budget = Budget(
                user_id=payload.user_id,
                category=payload.category,
                monthly_limit=payload.monthly_limit
            )
            s.add(budget)
        
        s.commit()
        return {"message": f"Budget set for {payload.category}: €{payload.monthly_limit}/month"}

@app.get("/budgets")
def get_budgets(user_id: str):
    """Get all budgets with current spending vs limits"""
    if not user_id:
        raise HTTPException(400, "Invalid user_id")
    
    with Session(engine) as s:
        if not s.exec(select(User).where(User.user_id == user_id)).first():
            raise HTTPException(404, "User not found")
        
        budgets = s.exec(select(Budget).where(Budget.user_id == user_id)).all()
        
        # Get current month spending by category
        current_month = datetime.utcnow().strftime("%Y-%m")
        month_txns = s.exec(
            select(Transaction).where(
                Transaction.user_id == user_id,
                Transaction.month == current_month
            )
        ).all()
        
        category_spending = {}
        for tx in month_txns:
            if tx.category:
                category_spending[tx.category] = category_spending.get(tx.category, 0) + abs(tx.amount)
        
        budget_status = []
        for budget in budgets:
            spent = category_spending.get(budget.category, 0)
            percentage = (spent / budget.monthly_limit * 100) if budget.monthly_limit > 0 else 0
            
            budget_status.append({
                "category": budget.category,
                "monthly_limit": budget.monthly_limit,
                "spent": spent,
                "remaining": budget.monthly_limit - spent,
                "percentage": round(percentage, 1),
                "status": "over" if spent > budget.monthly_limit else "warning" if percentage > 80 else "good"
            })
        
        return {
            "user_id": user_id,
            "budgets": budget_status,
            "month": current_month
        }

@app.post("/goals")
def create_goal(payload: GoalPayload):
    """Create a financial goal"""
    with Session(engine) as s:
        if not s.exec(select(User).where(User.user_id == payload.user_id)).first():
            raise HTTPException(404, "User not found")
        
        goal = Goal(
            user_id=payload.user_id,
            title=payload.title,
            target_amount=payload.target_amount,
            target_date=payload.target_date,
            goal_type=payload.goal_type,
            category=payload.category
        )
        s.add(goal)
        s.commit()
        
        return {"message": f"Goal '{payload.title}' created successfully"}

@app.get("/goals")
def get_goals(user_id: str):
    """Get all goals with progress"""
    if not user_id:
        raise HTTPException(400, "Invalid user_id")
    
    with Session(engine) as s:
        if not s.exec(select(User).where(User.user_id == user_id)).first():
            raise HTTPException(404, "User not found")
        
        goals = s.exec(select(Goal).where(Goal.user_id == user_id)).all()
        
        goal_progress = []
        for goal in goals:
            # Calculate progress based on goal type
            if goal.goal_type == "spending_reduction" and goal.category:
                # Calculate spending reduction progress
                current_month = datetime.utcnow().strftime("%Y-%m")
                last_month = (datetime.utcnow() - timedelta(days=30)).strftime("%Y-%m")
                
                current_spending = sum(
                    abs(tx.amount) for tx in s.exec(
                        select(Transaction).where(
                            Transaction.user_id == user_id,
                            Transaction.category == goal.category,
                            Transaction.month == current_month
                        )
                    ).all()
                )
                
                last_spending = sum(
                    abs(tx.amount) for tx in s.exec(
                        select(Transaction).where(
                            Transaction.user_id == user_id,
                            Transaction.category == goal.category,
                            Transaction.month == last_month
                        )
                    ).all()
                )
                
                reduction = last_spending - current_spending
                progress = min((reduction / goal.target_amount * 100), 100) if goal.target_amount > 0 else 0
            else:
                # For savings goals, use current_amount
                progress = (goal.current_amount / goal.target_amount * 100) if goal.target_amount > 0 else 0
            
            days_left = (goal.target_date - datetime.utcnow()).days
            
            goal_progress.append({
                "id": goal.id,
                "title": goal.title,
                "target_amount": goal.target_amount,
                "current_amount": goal.current_amount,
                "progress": round(progress, 1),
                "goal_type": goal.goal_type,
                "category": goal.category,
                "target_date": goal.target_date.isoformat(),
                "days_left": max(0, days_left),
                "achieved": goal.achieved or progress >= 100
            })
        
        return {
            "user_id": user_id,
            "goals": goal_progress
        }

@app.get("/health")
def health_check():
    """Health check endpoint for monitoring"""
    try:
        with Session(engine) as s:
            # Test database connection
            s.exec(select(User).limit(1)).first()
        return {
            "status": "healthy",
            "database": "connected",
            "timestamp": datetime.utcnow().isoformat()
        }
    except Exception as e:
        logger.error(f"Health check failed: {e}")
        return JSONResponse(
            status_code=503,
            content={
                "status": "unhealthy",
                "database": "disconnected",
                "error": str(e),
                "timestamp": datetime.utcnow().isoformat()
            }
        )
@app.post("/classify")
def classify(p:ClassifyPayload):
    updated=0
    with Session(engine) as s:
        txns = s.exec(select(Transaction).where(Transaction.user_id==p.user_id)).all()
        for t in txns:
            if not t.enriched:
                t.category = ml_categorize(t)
                t.enriched=True
                s.add(t)
                updated+=1
        s.commit()
    return {"msg":f'{updated} categorized'}

@app.get("/chart-data")
def get_chart(user_id: str, period: str = "30d"):
    """Get chart data for specified period (30d, 60d, 90d, 6m, 1y)"""
    if not user_id or not isinstance(user_id, str):
        return {"daily":[], "category":{}, "month":{}}

    # Parse period
    period_days = {
        "30d": 30,
        "60d": 60, 
        "90d": 90,
        "6m": 180,
        "1y": 365
    }
    days = period_days.get(period, 30)

    try:
        with Session(engine) as session:
            txns = session.exec(select(Transaction).where(Transaction.user_id==user_id)).all()
    except Exception as e:
        logger.error(f"Database error in chart_data: {e}")
        return {"daily":[], "category":{}, "month":{}}

    if not txns:
        return {"daily":[], "category":{}, "month":{}}

    # Filter by period
    cutoff = datetime.utcnow() - timedelta(days=days)
    day_tot={}
    cat_tot={}
    month_tot={}
    week_tot={}

    for t in txns:
        if t.date < cutoff:
            continue
        day = t.date.strftime("%Y-%m-%d")
        day_tot[day]=day_tot.get(day,0)+abs(t.amount)
        if t.category:
            cat_tot[t.category]=cat_tot.get(t.category,0)+abs(t.amount)
        month = t.date.strftime("%Y-%m")
        month_tot[month]=month_tot.get(month,0)+abs(t.amount)
        week = f"{t.date.strftime('%Y')}-W{t.iso_week}"
        week_tot[week]=week_tot.get(week,0)+abs(t.amount)

    daily = [{"date":d,"total":round(v,2)} for d,v in sorted(day_tot.items())]
    weekly = [{"week":w,"total":round(v,2)} for w,v in sorted(week_tot.items())]

    return {
        "daily": daily, 
        "weekly": weekly,
        "category": cat_tot, 
        "month": month_tot,
        "period": period,
        "period_days": days
    }

@app.get("/recurring-calendar")
def get_recurring_calendar(user_id: str):
    """Get recurring payments calendar view"""
    if not user_id:
        raise HTTPException(400, "Invalid user_id")
    
    with Session(engine) as s:
        if not s.exec(select(User).where(User.user_id == user_id)).first():
            raise HTTPException(404, "User not found")
        
        # Get recurring transactions from last 90 days
        cutoff = datetime.utcnow() - timedelta(days=90)
        recurring_txns = s.exec(
            select(Transaction).where(
                Transaction.user_id == user_id,
                Transaction.is_recurring == True,
                Transaction.date >= cutoff
            ).order_by(Transaction.date.desc())
        ).all()
        
        # Group by merchant and analyze patterns
        merchant_patterns = {}
        for tx in recurring_txns:
            if tx.merchant not in merchant_patterns:
                merchant_patterns[tx.merchant] = {
                    "transactions": [],
                    "amounts": [],
                    "category": tx.category
                }
            merchant_patterns[tx.merchant]["transactions"].append(tx.date)
            merchant_patterns[tx.merchant]["amounts"].append(abs(tx.amount))
        
        # Calculate next expected payment dates
        recurring_calendar = []
        for merchant, data in merchant_patterns.items():
            if len(data["transactions"]) >= 2:
                # Sort dates
                dates = sorted(data["transactions"])
                
                # Calculate average interval
                intervals = []
                for i in range(1, len(dates)):
                    diff = (dates[i] - dates[i-1]).days
                    intervals.append(diff)
                
                avg_interval = sum(intervals) / len(intervals) if intervals else 30
                avg_amount = sum(data["amounts"]) / len(data["amounts"])
                
                # Predict next payment
                last_payment = dates[-1]
                next_payment = last_payment + timedelta(days=int(avg_interval))
                
                # Only include future payments within next 60 days
                if next_payment > datetime.utcnow() and next_payment <= datetime.utcnow() + timedelta(days=60):
                    recurring_calendar.append({
                        "merchant": merchant,
                        "category": data["category"],
                        "next_payment_date": next_payment.isoformat(),
                        "expected_amount": round(avg_amount, 2),
                        "interval_days": int(avg_interval),
                        "confidence": min(len(data["transactions"]) * 20, 100)  # Higher confidence with more data points
                    })
        
        # Sort by next payment date
        recurring_calendar.sort(key=lambda x: x["next_payment_date"])
        
        return {
            "user_id": user_id,
            "recurring_payments": recurring_calendar,
            "total_monthly_recurring": sum(
                payment["expected_amount"] for payment in recurring_calendar 
                if payment["interval_days"] <= 35  # Roughly monthly
            )
        }

@app.get("/forecast")
def forecast(user_id:str):
    return forecast_balance(user_id)