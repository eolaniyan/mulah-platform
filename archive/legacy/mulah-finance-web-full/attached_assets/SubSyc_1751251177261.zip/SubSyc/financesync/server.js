
const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const { v4: uuidv4 } = require('uuid');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = process.env.PORT || 5000;

app.use(express.json());
app.use(express.static('public'));

// Initialize SQLite database
const dbPath = path.join(__dirname, 'financesync.db');
const db = new sqlite3.Database(dbPath);

// Create tables
db.serialize(() => {
  // Users table
  db.run(`CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    plan TEXT DEFAULT 'free',
    token TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )`);

  // Subscriptions table (from SubSync)
  db.run(`CREATE TABLE IF NOT EXISTS subscriptions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    name TEXT NOT NULL,
    cost REAL NOT NULL,
    cycle TEXT NOT NULL,
    next_date TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users (id)
  )`);

  // Transactions table (from My-Finance)
  db.run(`CREATE TABLE IF NOT EXISTS transactions (
    id TEXT PRIMARY KEY,
    user_id INTEGER,
    date DATETIME NOT NULL,
    amount REAL NOT NULL,
    description TEXT NOT NULL,
    merchant TEXT NOT NULL,
    category TEXT,
    is_recurring BOOLEAN DEFAULT 0,
    iso_week INTEGER,
    month TEXT,
    enriched BOOLEAN DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users (id)
  )`);

  // Budgets table
  db.run(`CREATE TABLE IF NOT EXISTS budgets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    category TEXT NOT NULL,
    monthly_limit REAL NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users (id)
  )`);

  // Goals table
  db.run(`CREATE TABLE IF NOT EXISTS goals (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    title TEXT NOT NULL,
    target_amount REAL NOT NULL,
    current_amount REAL DEFAULT 0,
    target_date DATETIME NOT NULL,
    goal_type TEXT NOT NULL,
    category TEXT,
    achieved BOOLEAN DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users (id)
  )`);

  // Insert demo users
  const demoUsers = [
    { name: 'Free User Demo', email: 'free@demo.com', password: 'demo123', plan: 'free' },
    { name: 'Premium User Demo', email: 'premium@demo.com', password: 'demo123', plan: 'premium' }
  ];

  demoUsers.forEach(user => {
    db.run(
      `INSERT OR IGNORE INTO users (name, email, password, plan) VALUES (?, ?, ?, ?)`,
      [user.name, user.email, user.password, user.plan]
    );
  });

  // Insert demo subscriptions
  setTimeout(() => {
    const demoSubs = [
      { email: 'free@demo.com', name: 'Netflix', cost: 12.99, cycle: 'monthly', next_date: '2025-02-05' },
      { email: 'free@demo.com', name: 'Spotify', cost: 9.99, cycle: 'monthly', next_date: '2025-02-08' },
      { email: 'premium@demo.com', name: 'Netflix', cost: 15.49, cycle: 'monthly', next_date: '2025-02-03' },
      { email: 'premium@demo.com', name: 'Adobe Creative Suite', cost: 52.99, cycle: 'monthly', next_date: '2025-02-15' }
    ];

    demoSubs.forEach(sub => {
      db.get(`SELECT id FROM users WHERE email = ?`, [sub.email], (err, user) => {
        if (user) {
          db.run(
            `INSERT OR IGNORE INTO subscriptions (user_id, name, cost, cycle, next_date) VALUES (?, ?, ?, ?, ?)`,
            [user.id, sub.name, sub.cost, sub.cycle, sub.next_date]
          );
        }
      });
    });
  }, 100);
});

// Authentication helpers
function generateToken() {
  return Math.random().toString(36).substr(2) + Date.now().toString(36);
}

function getUserFromToken(token, callback) {
  db.get(`SELECT * FROM users WHERE token = ?`, [token], callback);
}

// Category classification (ported from My-Finance)
const CATEGORY_KEYWORDS = {
  "Transport - Fuel": ["fuel", "diesel", "gas", "unleaded", "petrol", "bp", "shell", "texaco", "esso"],
  "Groceries": ["aldi", "tesco", "lidl", "spar", "grocery", "supermarket", "supervalu"],
  "Transport - Ride": ["uber", "bolt", "taxi", "lyft", "transport", "bus", "train"],
  "Subscriptions": ["netflix", "spotify", "prime", "apple music", "youtube premium", "disney+", "subscription"],
  "Dining": ["restaurant", "cafe", "food", "burger", "kfc", "mcdonalds", "starbucks", "pizza", "takeaway"],
  "Shopping": ["amazon", "store", "shop", "mall", "ebay", "clothing", "electronics", "zara"],
  "Bills & Utilities": ["electric", "gas bill", "water", "internet", "phone", "utility", "broadband"],
  "Entertainment": ["cinema", "movie", "theatre", "concert", "game", "steam", "gym", "netflix"],
  "Healthcare": ["pharmacy", "doctor", "hospital", "dental", "medical", "health"]
};

function categorizeTransaction(description, merchant) {
  const text = `${description} ${merchant}`.toLowerCase();
  
  for (const [category, keywords] of Object.entries(CATEGORY_KEYWORDS)) {
    for (const keyword of keywords) {
      if (text.includes(keyword)) {
        return category;
      }
    }
  }
  return "Misc";
}

// Routes

// Auth routes
app.post('/api/auth/register', (req, res) => {
  const { name, email, password } = req.body;
  
  db.get(`SELECT id FROM users WHERE email = ?`, [email], (err, user) => {
    if (user) {
      return res.status(400).json({ error: 'User already exists' });
    }
    
    const token = generateToken();
    db.run(
      `INSERT INTO users (name, email, password, token) VALUES (?, ?, ?, ?)`,
      [name, email, password, token],
      function(err) {
        if (err) {
          return res.status(500).json({ error: 'Registration failed' });
        }
        
        res.status(201).json({
          token,
          user: { id: this.lastID, name, email, plan: 'free' }
        });
      }
    );
  });
});

app.post('/api/auth/login', (req, res) => {
  const { email, password } = req.body;
  
  db.get(`SELECT * FROM users WHERE email = ? AND password = ?`, [email, password], (err, user) => {
    if (!user) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }
    
    const token = generateToken();
    db.run(`UPDATE users SET token = ? WHERE id = ?`, [token, user.id], (err) => {
      if (err) {
        return res.status(500).json({ error: 'Login failed' });
      }
      
      res.json({
        token,
        user: { id: user.id, name: user.name, email: user.email, plan: user.plan || 'free' }
      });
    });
  });
});

// Subscription routes (from SubSync)
app.get('/api/subscriptions', (req, res) => {
  const token = req.headers.authorization?.replace('Bearer ', '');
  
  if (!token) {
    return res.json([]);
  }
  
  getUserFromToken(token, (err, user) => {
    if (!user) {
      return res.json([]);
    }
    
    db.all(`SELECT * FROM subscriptions WHERE user_id = ? ORDER BY next_date`, [user.id], (err, rows) => {
      res.json(rows || []);
    });
  });
});

app.post('/api/subscriptions', (req, res) => {
  const { name, cost, cycle, nextDate } = req.body;
  const token = req.headers.authorization?.replace('Bearer ', '');
  
  getUserFromToken(token, (err, user) => {
    if (!user) {
      return res.status(401).json({ error: 'Unauthorized' });
    }
    
    db.run(
      `INSERT INTO subscriptions (user_id, name, cost, cycle, next_date) VALUES (?, ?, ?, ?, ?)`,
      [user.id, name, cost, cycle, nextDate],
      function(err) {
        if (err) {
          return res.status(500).json({ error: 'Failed to create subscription' });
        }
        res.status(201).json({ id: this.lastID });
      }
    );
  });
});

app.delete('/api/subscriptions/:id', (req, res) => {
  const { id } = req.params;
  
  db.run(`DELETE FROM subscriptions WHERE id = ?`, [id], function(err) {
    if (err) {
      return res.status(500).json({ error: 'Failed to delete subscription' });
    }
    res.json({ message: 'Subscription deleted' });
  });
});

// Finance routes (ported from My-Finance)
app.post('/api/transactions/sync', (req, res) => {
  const { user_id, transactions } = req.body;
  
  if (!transactions || !Array.isArray(transactions)) {
    return res.status(400).json({ error: 'Invalid transactions data' });
  }
  
  // Get user by user_id (email in this case)
  db.get(`SELECT id FROM users WHERE email = ?`, [user_id], (err, user) => {
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }
    
    let completed = 0;
    const errors = [];
    
    if (transactions.length === 0) {
      return res.json({ status: 'success', synced_count: 0 });
    }
    
    transactions.forEach((tx, index) => {
      const {
        id,
        date,
        amount,
        description,
        merchant
      } = tx;
      
      // Validate required fields
      if (!id || !date || !amount || !description || !merchant) {
        errors.push(`Transaction ${index}: Missing required fields`);
        completed++;
        if (completed === transactions.length) {
          return res.status(400).json({ status: 'error', errors });
        }
        return;
      }
      
      const category = categorizeTransaction(description, merchant);
      const txDate = new Date(date);
      const month = txDate.toISOString().slice(0, 7); // YYYY-MM
      const isoWeek = getISOWeek(txDate);
      
      db.run(
        `INSERT OR REPLACE INTO transactions 
         (id, user_id, date, amount, description, merchant, category, month, iso_week, enriched) 
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [id, user.id, date, amount, description, merchant, category, month, isoWeek, 1],
        function(err) {
          completed++;
          if (err) {
            errors.push(`Transaction ${index}: ${err.message}`);
          }
          
          if (completed === transactions.length) {
            if (errors.length > 0) {
              return res.status(400).json({ status: 'partial_success', errors, synced_count: completed - errors.length });
            }
            res.json({ status: 'success', synced_count: completed });
          }
        }
      );
    });
  });
});

app.get('/api/transactions', (req, res) => {
  const { user_id, limit = 50 } = req.query;
  
  db.get(`SELECT id FROM users WHERE email = ?`, [user_id], (err, user) => {
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }
    
    db.all(
      `SELECT * FROM transactions WHERE user_id = ? ORDER BY date DESC LIMIT ?`,
      [user.id, parseInt(limit)],
      (err, rows) => {
        if (err) {
          return res.status(500).json({ error: 'Failed to fetch transactions' });
        }
        res.json({ transactions: rows || [], count: rows?.length || 0 });
      }
    );
  });
});

app.get('/api/insights', (req, res) => {
  const { user_id, period = '30d' } = req.query;
  
  const periodDays = {
    '30d': 30, '60d': 60, '90d': 90, '6m': 180, '1y': 365
  };
  const days = periodDays[period] || 30;
  const cutoffDate = new Date(Date.now() - days * 24 * 60 * 60 * 1000).toISOString();
  
  db.get(`SELECT id FROM users WHERE email = ?`, [user_id], (err, user) => {
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }
    
    db.all(
      `SELECT * FROM transactions WHERE user_id = ? AND date >= ? ORDER BY date DESC`,
      [user.id, cutoffDate],
      (err, transactions) => {
        if (err || !transactions) {
          return res.status(500).json({ error: 'Failed to fetch insights' });
        }
        
        const totalSpend = transactions.reduce((sum, tx) => sum + Math.abs(tx.amount), 0);
        const avgTransaction = transactions.length > 0 ? totalSpend / transactions.length : 0;
        
        // Category breakdown
        const categoryAmounts = {};
        transactions.forEach(tx => {
          if (tx.category) {
            categoryAmounts[tx.category] = (categoryAmounts[tx.category] || 0) + Math.abs(tx.amount);
          }
        });
        
        const topCategory = Object.keys(categoryAmounts).reduce((a, b) => 
          categoryAmounts[a] > categoryAmounts[b] ? a : b, 'None');
        
        res.json({
          user_id,
          period,
          total_transactions: transactions.length,
          total_spend: Math.round(totalSpend * 100) / 100,
          avg_transaction: Math.round(avgTransaction * 100) / 100,
          top_category: topCategory,
          category_breakdown: categoryAmounts
        });
      }
    );
  });
});

// Helper function for ISO week
function getISOWeek(date) {
  const target = new Date(date.valueOf());
  const dayNr = (date.getDay() + 6) % 7;
  target.setDate(target.getDate() - dayNr + 3);
  const jan4 = new Date(target.getFullYear(), 0, 4);
  const dayDiff = (target - jan4) / 86400000;
  return 1 + Math.ceil(dayDiff / 7);
}

app.listen(PORT, '0.0.0.0', () => {
  console.log(`FinanceSync running on port ${PORT}`);
});
