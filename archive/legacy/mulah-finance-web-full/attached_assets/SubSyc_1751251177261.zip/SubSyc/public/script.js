async function fetchSubs() {
  const res = await fetch('/api/subscriptions');
  const data = await res.json();
  const tbody = document.getElementById('subsBody');
  tbody.innerHTML = '';
  data.forEach(s => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td class="px-4 py-2">${s.name}</td>
      <td class="px-4 py-2">€${s.cost.toFixed(2)}</td>
      <td class="px-4 py-2">${s.cycle}</td>
      <td class="px-4 py-2">${s.nextDate}</td>
    `;
    tbody.appendChild(tr);
  });
  const total = data.reduce((sum, s) => sum + s.cost, 0);
  document.getElementById('total').textContent = `€${total.toFixed(2)}`;
}

async function addSub(e) {
  e.preventDefault();
  const name = document.getElementById('name').value;
  const cost = parseFloat(document.getElementById('cost').value);
  const cycle = document.getElementById('cycle').value;
  const nextDate = document.getElementById('nextDate').value;
  await fetch('/api/subscriptions', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name, cost, cycle, nextDate })
  });
  e.target.reset();
  fetchSubs();
}

async function payAll() {
  const res = await fetch('/api/payall', { method: 'POST' });
  const data = await res.json();
  alert(data.message);
}

document.getElementById('subForm').addEventListener('submit', addSub);
document.getElementById('payBtn').addEventListener('click', payAll);

fetchSubs();
